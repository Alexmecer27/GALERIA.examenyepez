﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Galeria_Arte.Models
{
    internal class Visitante
    {
        public int ID_Visitante { get; set; }
        public string Nombre { get; set; }
        public int ID_Exposicion { get; set; }
    }
}
